<?php

include "Produto.php"


class Jogos extends Produto {

//Classe Jogos
    private $titulo;
    private $plataforma;
    private $descricao;
    private $anopubli;
    private $preco;
    private $genero;

    //Métodos

    //Metodo _construct()
    public function __construct($titulo, $plataforma, $descricao, $anopubli, $preco, $genero){
        $this -> setTitulo($titulo);
        $this -> setAutor($plataforma);
        $this -> setAnopubli($anopubli);
        $this -> setPreco($preco);
        $this -> setGenero($genero);

    }//Fim do Metodo __construct

    //Metodo setTitulo()
    public function setTitulo($titulo) {
        $this -> titulo = $titulo;
        }//Fim do Metodo setTitulo()
    
        //Metodo getTitulo()
        public function getTitulo () {
        return $this -> titulo;
        }//Fim do Metodo getTitulo()

        //Metodo setPlataforma()
    public function setPlataforma($plataforma) {
        $this -> plataforma = $plataforma;
        }//Fim do Metodo setPlataforma()
    
        //Metodo getPlataforma()
        public function getPlataforma () {
        return $this -> plataforma;
        }//Fim do Metodo getPlataforma()

    //Metodo setAnopubli 
    public function setAnopubli () {
    $this -> anopubli = $anopubli;
    }//Fim do Metodo setAnopubli

    //Metodo getAnopubli
    public function getAnopubli () {
        return $this -> anopubli;
    }//Fim do Metodo anopubli

    //Metodo setPreco 
    public function setPreco () {
    $this -> preco = $preco;
    }//Fim do Metodo setNacionalidade

    //Metodo getPreco
    public function getPreco() {
        return $this -> preco;
    }//Fim do Metodo getPreco

    //Metodo setGenero
    public function setGenero () {
     $this -> genero = $genero;
    }//Fim do Metodo setGenero
    
    //Metodo getGenero
    public function getGenero () {
        return $this -> genero;
    }//Fim do Metodo getGenero


} //Fim da classe Jogos
?>