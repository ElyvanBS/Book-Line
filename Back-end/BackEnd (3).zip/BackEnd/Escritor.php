<?php

class Escritor extends Usuario{

    private $genero;
    private $website;
    private $nacionalidade;
    private $descricao;

    public function __construct($genero, $website, $nacionalidade, $descricao, $nome, $telefone, $email, $senha, $cpf)
    {
        parent::__construct($nome, $telefone, $email, $senha, $cpf)
        $this ->genero = $genero;
        $this ->website = $website;
        $this ->nacionalidade = $nacionalidade;
        $this ->descricao = $descricao 
}

//Metodo setgenero()
public function setGenero () {
    $this -> genero = $genero;
}//Fim do Metodo setGenero

//Metodo getGenero
public function getGenero () {
    return $this -> genero;
}//Fim do Metodo getGenero

//Metodo setWebsite 
public function setWebsite () {
$this -> website = $website;
}//Fim do Metodo setwebsite

//Metodo getWebsite
public function getWebsite () {
    return $this -> website;
}//Fim do Metodo Website

//Metodo setNacionalidade 
public function setNacionalidade () {
$this -> nacionalidade = $nacionalidade;
}//Fim do Metodo setNacionalidade

//Metodo getNacionalidade
public function getNacionalidade() {
    return $this -> nacionalidade;
}//Fim do Metodo Nacionalidade


}



?>


