<?php 

   include "Produto.php";
   class Livro extends Produto {

    <?php 
    //Classe Livro
    class Livro {
        private $id;
        private $titulo;
        private $autor;
        private $fabricante;
        private $anopubli;
        private $preco;
        private $estoque;
        private $genero;
    
        //Métodos
    
        //Metodo _construct()
        public function __construct($id, $titulo, $autor, $fabricante, $anopubli, $preco, $estoque, $genero){
            $this -> setId($id);
            $this -> setTitulo($titulo);
            $this -> setAutor($autor);
            $this -> setEditora($fabricante);
            $this -> setAnopubli($anopubli);
            $this -> setPreco($preco);
            $this -> setEstoque($estoque);
            $this -> setGenero($genero);
    
        }//Fim do Metodo __construct
    
        //Método setID()
        public function setId($id){
            $this -> id = $id;
        }//Fim do Método setId()
    
        //Método getID()
        public function getId () {
            return $this->id;
        }//Fim do Metodo getID()
    
        //Metodo setTitulo()
        public function setTitulo($titulo) {
            $this -> titulo = $titulo;
            }//Fim do Metodo setTitulo()
        
            //Metodo getTitulo()
            public function getTitulo () {
            return $this -> titulo;
            }//Fim do Metodo getTitulo()
    
            //Metodo setAutor()
        public function setAutor($autor) {
            $this -> autor = $autor;
            }//Fim do Metodo setAutor()
        
            //Metodo getAutor()
            public function getAutor () {
            return $this -> autor;
            }//Fim do Metodo getAutor()
    
            //Metodo setFabricante()
        public function setFabricante () {
            $this -> fabricante = $fabricante;
        }//Fim do Metodo setFabricante
    
        //Metodo getFabricante
        public function getFabricante () {
            return $this -> fabricante;
        }//Fim do Metodo getFabricante
    
        //Metodo setAnopubli 
        public function setAnopubli () {
        $this -> anopubli = $anopubli;
        }//Fim do Metodo setAnopubli
    
        //Metodo getAnopubli
        public function getAnopubli () {
            return $this -> anopubli;
        }//Fim do Metodo anopubli
    
        //Metodo setPreco 
        public function setPreco () {
        $this -> preco = $preco;
        }//Fim do Metodo setNacionalidade
    
        //Metodo getPreco
        public function getPreco() {
            return $this -> preco;
        }//Fim do Metodo getPreco
    
    
        //Metodo setEstoque
        public function setEstoque () {
        $this -> estoque = $estoque;
        }//Fim do Metodo setEstoque
    
        //Metodo getEstoque
        public function getEstoque () {
            return $this -> estoque;
        }//Fim do Metodo getEstoque
    
        //Metodo setGenero
        public function setGenero () {
        $this -> genero = $genero;
        }//Fim do Metodo setGenero
    
        //Metodo getGenero
        public function getGenero () {
            return $this -> genero;
        }//Fim do Metodo getGenero
    
    
    
    } //Fim da classe Livro
    
    
    ?>


   }

?>