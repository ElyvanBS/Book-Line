<?php 

//Classe NovoEscritor
class Escritor {
    private $nome;
    private $telefone;
    private $email;
    private $genero;
    private $website;
    private $nacionalidade;
    private $descriçao;

    //Métodos
    //Metodo _construct()
    public function __construct($nome, $telefone, $email, $genero, $website, $nacionalidade, $descriçao){
        $this -> setNome($nome);
        $this -> setTelefone($telefone);
        $this -> setEmail($email);
        $this -> setgenero($genero);
        $this -> setWebsite($website);
        $this -> setNacionalidade($nacionalidade);
        $this -> setDescrição($descriçao);
    }//Fim do Metodo __construct

    //Método setNome()
    public function setNome($nome){
        $this -> nome = $nome;
    }//Fim do Método setNome()

    //Método getNome()
    public function getNome () {
        return $this->nome;
    }//Fim do Metodo getNome()

    //Metodo setTelefone()
    public function setTelefone($telefone) {
        $this -> telefone = $telefone;
        }//Fim do Metodo setTelefone()
    
        //Metodo getTelefone()
        public function getTelefone () {
        return $this -> telefone;
        }//Fim do Metodo getTelefone()

        //Metodo setEmail()
    public function setEmail($email) {
        $this -> email = $email;
        }//Fim do Metodo setEmail()
    
        //Metodo getEmail()
        public function getEmail () {
        return $this -> email;
        }//Fim do Metodo getEmail()

        //Metodo setgenero()
    public function setGenero () {
        $this -> genero = $genero;
    }//Fim do Metodo setGenero

    //Metodo getGenero
    public function getGenero () {
        return $this -> genero;
    }//Fim do Metodo getGenero

    //Metodo setWebsite 
    public function setWebsite () {
    $this -> website = $website;
    }//Fim do Metodo setwebsite

    //Metodo getWebsite
    public function getWebsite () {
        return $this -> website;
    }//Fim do Metodo Website

    //Metodo setNacionalidade 
public function setNacionalidade () {
    $this -> nacionalidade = $nacionalidade;
}//Fim do Metodo setNacionalidade

    //Metodo getNacionalidade
    public function getNacionalidade() {
        return $this -> nacionalidade;
    }//Fim do Metodo Nacionalidade


    //Metodo setDescricao 
public function setDescricao () {
    $this -> descricao = $descricao;
}//Fim do Metodo setDescricao

    //Metodo getDescricao
    public function getDescricao () {
        return $this -> descricao;
    }//Fim do Metodo Descricao

} //Fim da classe Escritor


?>