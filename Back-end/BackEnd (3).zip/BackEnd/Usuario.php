<?php 

//Classe Usuário
class Usuario {
    private $nome;
    private int $telefone;
    private $email;
    private $senha;
    private $cpf;
    

    //Métodos
    //Metodo _construct()
    public function __construct($nome, $telefone, $email, $senha, $cpf){
        $this -> setNome($nome);
        $this -> setTelefone($telefone);
        $this -> setEmail($email);
        $this -> setSenha($senha)
        $this -> setCpf($cpf)
    }//Fim do Metodo __construct

    //Método setNome()
    public function setNome($nome){
        $this -> nome = $nome;
    }//Fim do Método setNome()

    //Método getNome()
    public function getNome () {
        return $this->nome;
    }//Fim do Metodo getNome()

    //Metodo setTelefone()
    public function setTelefone($telefone) {
        $this -> telefone = $telefone;
        }//Fim do Metodo setTelefone()
    
        //Metodo getTelefone()
        public function getTelefone () {
        return $this -> telefone;
        }//Fim do Metodo getTelefone()

        //Metodo setEmail()
    public function setEmail($email) {
        $this -> email = $email;
        }//Fim do Metodo setEmail()
    
        //Metodo getEmail()
        public function getEmail () {
        return $this -> email;
        }//Fim do Metodo getEmail()

        //Metodo setSenha()
    public function setSenha () {
        $this -> senha = $senha;
    }//Fim do Metodo setSenha

    //Metodo getSenha
    public function getSenha () {
        return $this -> senha;
    }//Fim do Metodo getSenha

    //Metodo setCPF 
    public function setCpf () {
    $this -> cpf = $cpf;
    }//Fim do Metodo setCPF

    //Metodo getCPF
    public function getCpf () {
        return $this -> cpf;
    }//Fim do Metodo getCPF



} //Fim da classe Usuário


?>




