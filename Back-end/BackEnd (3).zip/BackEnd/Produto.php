<?php 
//Classe Produto
class Produto {
    private $id;
    private $titulo;
    private $fabricante;
    private $preco;
    private $estoque;
    private $descricao

    //Métodos

    //Metodo _construct()
    public function __construct($id, $titulo, $fabricante, $preco, $estoque){
        $this -> setId($id);
        $this -> setTitulo($titulo);
        $this -> setEditora($fabricante);
        $this -> setPreco($preco);
        $this -> setEstoque($estoque);

    }//Fim do Metodo __construct

    //Método setID()
    public function setId($id){
        $this -> id = $id;
    }//Fim do Método setId()

    //Método getID()
    public function getId () {
        return $this->id;
    }//Fim do Metodo getID()

    //Metodo setTitulo()
    public function setTitulo($titulo) {
        $this -> titulo = $titulo;
        }//Fim do Metodo setTitulo()
    
        //Metodo getTitulo()
        public function getTitulo () {
        return $this -> titulo;
        }//Fim do Metodo getTitulo()

        //Metodo setFabricante()
    public function setFabricante () {
        $this -> fabricante = $fabricante;
    }//Fim do Metodo setFabricante

    //Metodo getFabricante
    public function getFabricante () {
        return $this -> fabricante;
    }//Fim do Metodo getFabricante


    //Metodo setPreco 
    public function setPreco () {
    $this -> preco = $preco;
    }//Fim do Metodo setNacionalidade

    //Metodo getPreco
    public function getPreco() {
        return $this -> preco;
    }//Fim do Metodo getPreco


    //Metodo setEstoque
    public function setEstoque () {
    $this -> estoque = $estoque;
    }//Fim do Metodo setEstoque

    //Metodo getEstoque
    public function getEstoque () {
        return $this -> estoque;
    }//Fim do Metodo getEstoque

    //Método setDescrição
    public function setDescricao() {
        $this -> descricao = $descricao;
    }//Fim do Método setDescrição

    //Método getDescrição
   public function getDescricao (){
    return $this -> descricao;
}//Fim do Método getDescrição


} //Fim da classe Produto


?>