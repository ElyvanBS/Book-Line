<?php

    //Subclasse ContaPoupanca
    class ContaPoupanca extends Conta {
        //Atributos
        protected $limite

        //Métodos
        public function __contruct($agencia, $conta, $saldo, $limite) {
            parent::__construct();
            $this->limite = $limite;
        }
        //Método retirar()
        public function retirar ($quantia){
           if(($this->saldo + $this ->limite) >= $quantia){
            $this->saldo -= $quantia;
           }
           else{
            return false; //Retirada não autorizada;
           }
           return true; //Retirada autorizada

        }//Fim do método retirar()



    }//Fim da subclasse ContaPoupanca
?>