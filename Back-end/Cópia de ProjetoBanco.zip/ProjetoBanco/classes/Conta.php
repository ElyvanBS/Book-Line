<?php

    //Classe Conta
    class Conta{
        //atributos
        protected $agencia;
        protected $conta;
        protected $saldo;

        //Métodos

        //Método construtor
        public function __construct ($agencia, $conta, $saldo) {
            $this->agencia = $agencia;
            $this->conta = $conta;
            if ($saldo >= 0){
                $this->saldo = $saldo;
            }
        }

        //Método getInfo()
        public function getInfo(){
            return "Agência: { $this->agencia}, Conta: {$this->conta}";
        }//Fim do método getInfo();

        //Método depositar()
            public function depositar($quantia){
                if($quantia > 0){
                    $this->saldo += $quantia;
                }
            }//Fim do método depositar()

            //Método getSaldo()
            public function getSaldo(){
                return $this->saldo;
            }//Fim do método getSaldo()
        

    }//Fim da classe Conta

?>