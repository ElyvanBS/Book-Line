<?php

    //Subclasse ContaPoupanca
    class ContaPoupanca extends Conta {

        //Método retirar()
        function retirar ($quantia){
            if ($this->saldo >= $quantia){
                $this->saldo -= $quantia;
            }
            else {
                return false; //Retirada não é autorizada
            }
            return true; //Retirada foi autorizada
        }//Fim do método retirar
    }//Fim da subclasse ContaPoupanca
?>
